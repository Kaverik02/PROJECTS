import subprocess
import pandas as pd
import openpyxl
import datetime
from datetime import datetime, timedelta
import os
import shutil

def run_batch_file():
    batch_file_path1 = r'PART_1.bat'
    batch_file_path2 = r'PART_2.bat'

    process = subprocess.run(batch_file_path1, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

    for _ in range(8):
        process = subprocess.run(batch_file_path2, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        print(process.stdout.decode())
        print(process.stderr.decode())

def process_text_files_to_excel():
    input_files = [
        'set1.txt',
        'set2.txt',
        'set3.txt',
        'set4.txt',
        'set5.txt',
        'set6.txt',
        'set7.txt',
        'set8.txt',
        'set9.txt'
    ]

    output_files = [
        'set1.xlsx',
        'set2.xlsx',
        'set3.xlsx',
        'set4.xlsx',
        'set5.xlsx',
        'set6.xlsx',
        'set7.xlsx',
        'set8.xlsx',
        'set9.xlsx'
    ]

    merged_data = pd.DataFrame()

    for i, input_file in enumerate(input_files):
        with open(input_file, 'r') as file:
            lines = file.readlines()[4:]

        data = [line.strip().split('|') for line in lines]
        df = pd.DataFrame(data)

        df = df.drop(columns=[0])
        df = df.drop([1])

        output_file = output_files[i]
        df.to_excel(output_file, index=False, header=False)

    first_excel = pd.read_excel('set1.xlsx')

    merged_data = pd.DataFrame()
    
    for i in range(2, 10):
        filename = f'set{i}.xlsx'
        data = pd.read_excel(filename)
        data_subset = data.iloc[:, 6:18]
        merged_data = pd.concat([merged_data, data_subset], axis=1)

    final_data = pd.concat([first_excel, merged_data], axis=1)

    final_data.to_excel('merged.xlsx', index=False)


def change_column_names():

    start_column = 'G'
    file_path = "merged.xlsx"
    file_path2 = "Mergedweek.xlsx"

    workbook = openpyxl.load_workbook(file_path)

    sheet = workbook.active

    current_date = datetime.now()

    start_of_week = current_date - timedelta(days=current_date.weekday())

    start_week_number = start_of_week.isocalendar()[1]

    start_column_index = openpyxl.utils.column_index_from_string(start_column)

    for column_index, cell in enumerate(sheet.iter_cols(min_col=start_column_index, max_col=sheet.max_column, min_row=1, max_row=1)):

        week_number = start_week_number + column_index
        year = current_date.year

        
        year += (week_number - 1) // 52  # Adjusting year
        week_number %= 52  # Ensure week number is between 0 and 51

        if week_number == 0:
            week_number = 52

        week_date = start_of_week + timedelta(weeks=column_index)
        cell[0].value = f"{week_date.strftime('%d-%m-%Y')}/wk{week_number}"

    workbook.save(file_path2)

    input_filename = "Mergedweek.xlsx"

    df = pd.read_excel(input_filename, engine='openpyxl')

    df = df.apply(lambda x: x.str.split(',').str[0] if x.dtype == "object" else x)
    df = df.apply(lambda x: x.str.replace(".", "") if x.dtype == "object" else x)
    


    df.to_excel(input_filename, index=False)


def run_batch_file_year():
    batch_file_path1 = r'YEAR.bat'

    process = subprocess.run(batch_file_path1, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

    print(process.stderr.decode())

def text_file_to_excel():
    input_files = ['set_year1.txt']
    output_files = ['set_year1.xlsx']


    for i, input_file in enumerate(input_files):

        with open(input_file, 'r') as file:
            lines = file.readlines()[4:]

        data = [line.strip().split('|') for line in lines]
        df = pd.DataFrame(data)

        df = df.drop(columns=[0])
        df = df.drop([1])

        output_file = output_files[i]
        df.to_excel(output_file, index=False, header=False)


        df = pd.read_excel('set_year1.xlsx')
        present_year = datetime.now().year
        years = [str(year) for year in range(present_year, present_year + len(df.columns) - 1)]
        new_columns = [df.columns[0]] + years
        df.columns = new_columns
        df.to_excel('set_year1.xlsx', index=False)
        
        df = df.apply(lambda x: x.str.split(',').str[0] if x.dtype == "object" else x)
        df = df.apply(lambda x: x.str.replace(".", "") if x.dtype == "object" else x)

        df.to_excel('set_year1.xlsx', index=False)

        
def merge_excels():
    input_filename = "Mergedweek.xlsx"
    df1 = pd.read_excel(input_filename, engine='openpyxl')

    input_filename = "set_year1.xlsx"
    df2 = pd.read_excel(input_filename, engine='openpyxl')

    merged_df = pd.merge(df1, df2, on='Material                    ')

    merged_df.to_excel("Merged_output.xlsx", index=False)

    excel = "Merged_output.xlsx"
    df = pd.read_excel(excel, engine='openpyxl')
    empty_row_index = df.index[df.isnull().all(axis=1)].tolist()

    if empty_row_index:
        empty_row_index = empty_row_index[0]
        df = df.iloc[:empty_row_index]

    df.to_excel("Merged_output.xlsx", index=False)

    df.to_excel("Merged_output.xlsx", index=False)



def run_batch_file_pivot():
    batch_file_path1 = r'PIVOT.bat'

    process = subprocess.run(batch_file_path1, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

    print(process.stderr.decode())

def text_file_to_pivot_excel():
    input_file = 'pivot.txt'  
    output_file = 'pivot.xlsx' 

    with open(input_file, 'r') as file:
            lines = file.readlines()

    data = [line.strip().split('|') for line in lines]
    df = pd.DataFrame(data)
    df = df.drop([0])
    df = df.drop([2])

    df = df.apply(lambda x: x.str.split(',').str[0] if x.dtype == "object" else x)
    df = df.apply(lambda x: x.str.replace(".", "") if x.dtype == "object" else x)


    df.to_excel(output_file, index=False, header=False)
    print(f'Text file converted to Excel and saved as {output_file}')



def pivot():
    
    input_file = 'pivot.xlsx'
    pivot_table_df = pd.read_excel(input_file)

    pivot_table_df.rename(columns={'Material Code               ': 'Material                    '}, inplace=True)

    aggregated_df = pivot_table_df.groupby('Material                    ').agg({
        '    Open Quantity': 'sum',
        '         Conf Qty': 'sum'
    }).reset_index()

    output_file = 'excelpivot.xlsx'
    aggregated_df.to_excel(output_file, index=False)


    print(f'Transformed pivot table saved to {output_file}')


def addtoexcel():
    excel1 = pd.read_excel('Merged_output.xlsx')
    excel2 = pd.read_excel('excelpivot.xlsx')
    merged = excel1.merge(excel2, on='Material                    ', how='left').fillna(0)
    merged.to_excel('Final.xlsx', index=False)


def finalexcel():
    
    current_date = datetime.now()

    start_of_week = current_date - timedelta(days=current_date.weekday())

    start_week_number = start_of_week.isocalendar()[1]

    print(start_week_number)

    input_filename = "Final.xlsx"

    df1 = pd.read_excel(input_filename, engine='openpyxl')


    output_filename = f"Output_week{start_week_number}.xlsx"
    current_directory = "C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - MM\\FN_Demand_Forecast_ACR"
    output_path = os.path.join(current_directory, output_filename)

    try:
        if not os.path.exists(current_directory):
            os.makedirs(current_directory)

        df1.to_excel(output_path, index=False)
        print(f"Modified data saved to '{output_path}'")

        if os.path.exists(output_path):
            print(f"Output file for week {start_week_number} already exists. Replacing it...")
            destination_path = os.path.join(current_directory, output_filename)
            shutil.move(output_path, destination_path)
        else:
            print(f"Creating new output file for week {start_week_number}...")

        print(f"Output file '{output_filename}' has been created/modified.")

    except Exception as e:
        print("An error occurred:", e)


def main():
    run_batch_file()
    process_text_files_to_excel()
    change_column_names()
    run_batch_file_year()
    text_file_to_excel()
    merge_excels()
    run_batch_file_pivot()
    text_file_to_pivot_excel()
    pivot()
    addtoexcel()
    finalexcel()


if __name__ == "__main__":
    main()