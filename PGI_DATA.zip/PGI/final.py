import subprocess
import pandas as pd
import re
from openpyxl.styles import Font
from datetime import timedelta
import pandas as pd
import urllib.parse
from sqlalchemy import create_engine, inspect
import pyodbc
import datetime
from sqlalchemy import text

def rpa():
    batch_file_path1 = r'C:\\RPA Files\\Production\\PGI\\pgi_dn.bat'

# Execute the batch file
    subprocess.run(batch_file_path1, shell=True, check=True)


    file_path1 = r'C:\\RPA Files\\Production\\PGI\\new_report.txt'
    file_path2 = r'C:\\RPA Files\\Production\\PGI\\SFCList.txt'
    file = r'C:\\RPA Files\\Production\\PGI\\delivery.txt'
    excel_file_path = r'C:\\RPA Files\\Production\\PGI\\list.xlsx'
    excel_file_path2 = r'C:\\RPA Files\\Production\\PGI\\list22.xlsx'

    df = pd.read_csv(file_path1, delimiter='\t', header=0)
    all_data = df.astype(str).apply(lambda x: ' '.join(x), axis=1)

    pattern_numbers = re.compile(r'\b1\d{9}\b')
    pattern_date = re.compile(r'(\d{2}\.\d{2}\.\d{4})')
    pattern_time = re.compile(r'\b\d{2}:\d{2}:\d{2}\b')
    material_pattern = re.compile(r'(?:3FE\d{5}[A-Za-z]{2}|\b(?:47|3FE)\w+\.\d+)')

    delivery_numbers = []

    for row_data in all_data:
        delivery_numbers.extend(pattern_numbers.findall(row_data))

    #print(delivery_numbers)

        with open(file, "w") as f:
            for delivery_number in delivery_numbers:
                f.write(f"{delivery_number}\n")

    

    def extract_delivery_info(text):
        delivery_numbers = pattern_numbers.findall(text)
        dates = pattern_date.findall(text)
        times = pattern_time.findall(text)
        materials = material_pattern.findall(text)

        return zip(delivery_numbers, dates, times, materials)

    delivery_data = []
# Read the text file and process each line
    with open(file_path1, 'r') as file:
        for line in file:
            delivery_info_list = extract_delivery_info(line)
            for delivery_info in delivery_info_list:
                delivery_data.append(delivery_info)

    batch_file_path2 = r'C:\\RPA Files\\Production\\PGI\\pgi_sfc.bat'

    subprocess.run(batch_file_path2, shell=True, check=True)



    delivery_pattern = re.compile(r'^\|\s*(\d+)\s*\|')
    serial_pattern = re.compile(r'\b[A-Za-z0-9]{11}\b')
    material_pattern = re.compile(r'(?:3FE\d{5}[A-Za-z]{2}|\b(?:47|3FE)\w+\.\d+)')




    deliveries_materials_serials = []
    with open(file_path2, 'r') as file:
        lines = file.readlines()


    current_delivery = None
    for line in lines:
        delivery_match = delivery_pattern.match(line)
        if delivery_match:
            current_delivery = delivery_match.group(1)
        else:
            serial_numbers = serial_pattern.findall(line)
            material_numbers = material_pattern.findall(line)

            for serial_number, material_number in zip(serial_numbers, material_numbers):
                deliveries_materials_serials.append((current_delivery, material_number, serial_number))

    df = pd.DataFrame(deliveries_materials_serials, columns=['Delivery Number', 'Item', 'SFC'])
    df.to_excel(excel_file_path2, index=False)  
    
    return rpa



def update_pgi():
    try:
        server = '10.129.213.247'
        database = 'PGI'
        username = 'sa'
        password = 'iotserver@1'
        driver = '{ODBC Driver 17 for SQL Server}'

        connection_string = f'Driver={driver};Server={server};Database={database};Uid={username};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;'
        quoted = urllib.parse.quote_plus(connection_string)
        engine = create_engine(f'mssql+pyodbc:///?odbc_connect={quoted}', pool_pre_ping=True)

        connection = engine.connect()
        print("Connection successful!")

        excel_file_path = 'C:\\RPA Files\\Production\\PGI\\list22.xlsx'
        df = pd.read_excel(excel_file_path)

        table_name = 'pgied_data'

        # Check if the table exists
        inspector = inspect(engine)
        if inspector.has_table(table_name):
            # Get existing data from the table
            existing_data = pd.read_sql_query(f'SELECT * FROM {table_name}', engine)

            # Identify new records
            new_data = df[~df['SFC'].isin(existing_data['SFC'])]

            if not new_data.empty:
                # Append new records to existing table
                new_data.to_sql(name=table_name, con=engine, if_exists='append', index=False, chunksize=100000)
                print("Data appended to existing table.")
            else:
                print("No new data to append.")
        else:
            # Create table if it doesn't exist
            df.to_sql(name=table_name, con=engine, if_exists='replace', index=False, chunksize=100000)
            print("New table created.")

        query = f'SELECT * FROM {table_name}'
        result = pd.read_sql_query(query, engine)
        # print(result)

    except pd.io.sql.DatabaseError as e:
        print(f"Database error: {e}")
    except Exception as e:
        print(f"Error: {e}")

    finally:
        engine.dispose()
        print("Connection closed.")

def pack():
    server = 'mochn.database.windows.net'
    database = 'RFM'
    username = 'RFMUSR'
    password = 'Nokia@123'

    connection_string = f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={database};UID={username};PWD={password}'

    conn = pyodbc.connect(connection_string)

    today_date = datetime.datetime.now().strftime('%Y-%m-%d 00:00:00.000')
    #print(today_date)

    sql_query = '''
    SELECT [SFC]
      ,[DT_IST]
      ,[OPERATION]
      ,[ITEM]
      ,[VALUE]
  FROM [dbo].[TBL_RFM_PLCM_PROD_NEW]
  where OPERATION like '%PACK_IN04'
    '''
    df1 = pd.read_sql(sql_query, conn)

    df1 = df1.drop_duplicates(subset=['SFC'])

    conn.close()

    return df1

def pgi():
    server = '10.129.213.247'
    database = 'PGI'
    username = 'sa'
    password = 'iotserver@1'
    driver = '{ODBC Driver 17 for SQL Server}'

    connection_string = f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={database};UID={username};PWD={password}'

    conn = pyodbc.connect(connection_string)

    sql_query2 = '''
    SELECT  [Delivery Number]
      ,[Item]
      ,[SFC]
  FROM [PGI].[dbo].[pgied_data]
    '''

    df3 = pd.read_sql(sql_query2, conn)

    conn.close()

    return df3

# Load data from both tables
df_pack = pack()
df_pgi = pgi()

# Merge data based on 'SFC' column
df_result = df_pack[~df_pack['SFC'].isin(df_pgi['SFC'])]
#df_result = df_pack[df_pack['SFC'].isin(df_pgi['SFC'])]
df_result = df_result.drop_duplicates(subset='SFC', keep='first')



# Export result to Excel    
df_result.to_excel('C:\\RPA Files\\Production\\PGI\\result.xlsx', index=False)




def updatewait():
    server = '10.129.213.247'
    database = 'PGI'
    username = 'sa'
    password = 'iotserver@1'
    driver = '{ODBC Driver 17 for SQL Server}'

    connection_string = f'Driver={driver};Server={server};Database={database};Uid={username};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;'
    quoted = urllib.parse.quote_plus(connection_string)
    engine = create_engine(f'mssql+pyodbc:///?odbc_connect={quoted}', pool_pre_ping=True)

    try:
        connection = engine.connect()
        print("Connection successful!")

        excel_file_path2 = 'C:\\RPA Files\\Production\\PGI\\result.xlsx'
        df = pd.read_excel(excel_file_path2)

        table_name = 'waiting_for_pgi'

        inspector = inspect(engine)
        if inspector.has_table(table_name):
            #Delete old data from the table
            with engine.connect() as conn:
                conn.execute(text(f'DELETE FROM [PGI].[dbo].[waiting_for_pgi]'))
                conn.commit()
                print('deleted')

            # Append new data from Excel to the table
            df.to_sql(name=table_name, con=engine, if_exists='append', index=False, chunksize=100000)
            print("New data appended to existing table.")
        else:
            # Create table if it doesn't exist
            df.to_sql(name=table_name, con=engine, if_exists='replace', index=False, chunksize=100000)
            print("New table created.")

        query = f'SELECT * FROM {table_name}'
        result = pd.read_sql_query(query, engine)
        #print(result)

    except Exception as e:
        print(f"Connection error: {e}")




if __name__ == "__main__":
    rpa()
    update_pgi()
    pack()
    pgi()
    updatewait()