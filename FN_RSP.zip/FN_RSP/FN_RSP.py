import openpyxl
import pandas as pd
from datetime import datetime
import subprocess
import os

def extract_data(excel_file, sheet_name, start_row, start_column, output_file):
    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb[sheet_name]
        last_row = ws.max_row
        last_column = ws.max_column
        with open(output_file, 'w') as f:
            for row in range(start_row, last_row):
                row_data = []
                for col in range(start_column, last_column):
                    cell_value = ws.cell(row=row, column=col).value
                    if cell_value is None:
                        row_data.append('0')
                    else:
                        row_data.append(str(cell_value))
                f.write(' '.join(row_data) + '\n')
        print("Data extracted successfully to", output_file)

    except Exception as e:
        print("Error:", e)

extract_data('C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx', 'overview', 5, 3,
             'C:\\RPA Files\\PPC\\FN_RSP\\data.txt')

def copy_excel_to_text(excel_file, sheet_name, start_row, start_column, end_column, output_file):
    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb[sheet_name]
        last_row = ws.max_row
        last_column = ws.max_column
        with open(output_file, 'w') as f:
            for row in range(start_row, last_row):
                row_data = []
                for col in range(start_column, end_column + 1):
                    cell_value = ws.cell(row=row, column=col).value
                    row_data.append(str(cell_value))
                f.write('\t'.join(row_data) + '\n')
        print("Data extracted successfully to", output_file)

    except Exception as e:
        print("Error:", e)

copy_excel_to_text('C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx', 'overview', 5, 1, 1,
                   'C:\\RPA Files\\PPC\\FN_RSP\\deliverynum.txt')


# Read the Excel file
excel_file_path = 'C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx'
df = pd.read_excel(excel_file_path, header=None)


def get_week_number(date_value):
    if pd.notna(date_value) and date_value != 'Grand Total':
        if isinstance(date_value, datetime):
            week_number = int(date_value.strftime('%U')) + 1
        else:
            try:
                date_object = datetime.strptime(date_value, '%d-%b-%y')
                week_number = int(date_object.strftime('%U')) + 1
            except ValueError:
                return ''

        return str(week_number)
    else:
        return ''


date_columns = df.iloc[3, 2:]

df.loc[-1] = date_columns.apply(get_week_number)
df.index = df.index + 1
df.sort_index(inplace=True)

df.to_excel(excel_file_path, index=False, header=False)


first_week_value = str(df.iloc[0, 2])
with open('C:\\RPA Files\\PPC\\FN_RSP\\week.txt', 'w') as text_file:
    text_file.write(first_week_value)


batch_file_path1 = r'C:\\RPA Files\\PPC\\FN_RSP\\pra_req.bat'

# Execute the batch file
subprocess.run(batch_file_path1, shell=True, check=True)

file_path = "C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx"
os.remove(file_path)