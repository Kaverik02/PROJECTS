import openpyxl
import pandas as pd
from datetime import datetime
import subprocess
import os
from openpyxl import load_workbook
from openpyxl.styles import Font
import numpy as np


def copy_excel_to_text():
    excel_file = 'C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx'
    sheet_name = 'overview'
    start_row = 5
    start_column = 1
    end_column = 1
    output_file = 'C:\\RPA Files\\PPC\\FN_RSP\\deliverynum.txt'
    
    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb[sheet_name]
        last_row = ws.max_row
        last_column = ws.max_column
        with open(output_file, 'w') as f:
            for row in range(start_row, last_row):
                row_data = []
                for col in range(start_column, end_column + 1):
                    cell_value = ws.cell(row=row, column=col).value
                    row_data.append(str(cell_value))
                f.write('\t'.join(row_data) + '\n')
        print("Data extracted successfully to", output_file)

    except Exception as e:
        print("Error:", e)

def copy_cell_value():
    excel_file_path = 'C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx'
    excel_file_path2 = 'C:\\RPA Files\\PPC\\FN_RSP\\RSP2.xlsx'
    
    df = pd.read_excel(excel_file_path, header=None)
    df = df.drop([0, 1, 2])

    df = df.drop(columns=[0, 1])

    df = df.iloc[:-1]

    df = df.iloc[:, :-1]

    df.to_excel(excel_file_path2, index=False, header=False)

def update_missing_fridays():
    file_path = 'C:\\RPA Files\\PPC\\FN_RSP\\RSP2.xlsx'
    def generate_all_fridays(start_date, end_date):
        all_fridays = pd.date_range(start=start_date, end=end_date, freq='W-FRI')
        return all_fridays
    
    df = pd.read_excel(file_path)
    
    date_headers = pd.to_datetime(df.columns[1:-1], format='%m-%d-%Y %H:%M:%S')
    
    start_date = date_headers.min()
    end_date = date_headers.max()
    
    all_fridays = generate_all_fridays(start_date, end_date)
    
    missing_fridays = all_fridays.difference(date_headers)
    
    for missing_date in missing_fridays:
        formatted_date = missing_date.strftime('%m-%d-%Y %H:%M:%S')
        df[formatted_date] = np.nan
    
    df = df.reindex(sorted(df.columns, key=lambda x: pd.to_datetime(x, format='%m-%d-%Y %H:%M:%S') if x not in ['First_Column_Name', 'Last_Column_Name'] else x), axis=1)
    
    df.to_excel(file_path, index=False, engine='openpyxl')
    
    wb = load_workbook(file_path)
    ws = wb.active
    for cell in ws[1]:
        cell.font = Font(bold=False)
    
    wb.save(file_path)

def extract_data():
    excel_file = 'C:\\RPA Files\\PPC\\FN_RSP\\RSP2.xlsx'
    sheet_name = 'Sheet1'
    start_row = 2
    start_column = 1
    output_file = 'C:\\RPA Files\\PPC\\FN_RSP\\data.txt'

    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb[sheet_name]
        last_row = ws.max_row
        last_column = ws.max_column
        with open(output_file, 'w') as f:
            for row in range(start_row, last_row + 1): 
                row_data = []
                for col in range(start_column, last_column + 1):
                    cell_value = ws.cell(row=row, column=col).value
                    if cell_value is None:
                        row_data.append('0')
                    else:
                        row_data.append(str(cell_value))
                f.write(' '.join(row_data) + '\n')
        print("Data extracted successfully to", output_file)

    except Exception as e:
        print("Error:", e)

def get_total():
    excel_file = 'C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx'
    sheet_name = 'overview'
    start_row = 5
    output_file = 'C:\\RPA Files\\PPC\\FN_RSP\\total.txt'

    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb[sheet_name]
        last_row = ws.max_row
        last_column = ws.max_column
        with open(output_file, 'w') as f:
            for row in range(start_row, last_row): 
                cell_value = ws.cell(row=row, column=last_column - 1).value
                if cell_value is None:
                    cell_value = '0'
                f.write(str(cell_value) + '\n')
        print("Data extracted successfully to", output_file)

    except Exception as e:
        print("Error:", e)



def execute_batch_file():
    batch_file_path = 'C:\\RPA Files\\PPC\\FN_RSP\\pra_req.bat'
    subprocess.run(batch_file_path, shell=True, check=True)

def delete_file():
    file_path = 'C:\\Users\\vinod\\Nokia\\Chennai PBI Data Warehouse - PPC& WH\\FN_RSP\\RSP.xlsx'
    os.remove(file_path)

def main():
    copy_excel_to_text()
    copy_cell_value()
    update_missing_fridays()
    extract_data()
    get_total()
    execute_batch_file()
    delete_file()

if __name__ == "__main__":
    main()
